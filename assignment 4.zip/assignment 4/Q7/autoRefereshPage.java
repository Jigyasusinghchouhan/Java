package Q7;

public class autoRefereshPage {
    
}
